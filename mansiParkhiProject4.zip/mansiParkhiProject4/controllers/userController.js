const model = require('../models/user');
const Connection = require ('../models/connection'); 

exports.new = (req, res)=>{
    return res.render('./user/new');
};

exports.create = (req, res, next)=>{
        let user = new model(req.body);//create a new user document
        user.save()//insert the user into the database
        .then(user=>{
            if(user){
                req.flash('success', 'Registration Succeeded');
                res.redirect('/users/login');
            }})
        .catch(err=>{
            if(err.name === 'ValidationError' ) {
                req.flash('error', err.message);  
                return res.redirect('/users/new');
            }
    
            if(err.code === 11000) {
                req.flash('error', 'This Email has already been used');  
                return res.redirect('/users/new');
            }
            
            next(err);
        });
 
    };

exports.getUserLogin = (req, res, next) => {
        return  res.render('./user/login');

}

exports.login = (req, res, next)=>{
        let email = req.body.email;
        let password = req.body.password;
        model.findOne({ email: email })
        .then(user => {
            if (!user) {
                console.log('wrong email address');
                req.flash('error', 'Please enter correct Email !');  
                res.redirect('/users/login');
            } else {
                user.comparePassword(password)
                .then(result=>{
                    if(result) {
                        req.session.user = user._id;
                        req.session.firstName = user.firstName;
                        req.session.lastName = user.lastName;
                        req.flash('success', 'You have successfully logged in');
                        res.redirect('/users/profile');
                } else {
                    req.flash('error', 'Please enter correct Password !');      
                    res.redirect('/users/login');
                }
                });     
            }     
        })
        .catch(err => next(err));
    
};

exports.profile = (req, res, next)=>{
    let id = req.session.user;
    let hostName = req.session.user;
    Promise.all([model.findById(id) ,Connection.find({hostName: id})])
    .then(results=>{
        const [user, connections] = results;
        res.render('./user/profile', {user, connections});
    })
    .catch(err=>next(err));
};


exports.logout = (req, res, next)=>{
    req.session.destroy(err=>{
        if(err) 
           return next(err);
       else
            res.redirect('/users/login');  
    });
   
 };



