const model = require('../models/connection');


// show all the connections to the users
exports.index = (req, res, next) => { 
    model.distinct("connectionTopic", function(error, response){
        let connectionTopic = response;
         model.find()
        .then(connection_list => {
            res.render('./connection/index', {connections:connection_list, topics:connectionTopic})
        })
        .catch(err=>next(err));
    });    
};

// GET /connections/new : send html form for creating a new connection
exports.new = (req, res) => {
    res.render('./connection/new');
};


// POST /connections: create a new connection // We will add connection document into the database through this method 

exports.create = (req, res, next) =>{ 
    let connection = new model(req.body);
    connection.hostName = req.session.user;
    connection.save()
    .then(results=> {
        req.flash('success', 'Connection Created Successfully !');
        res.redirect('/connections');
    })
    .catch(err=>{
        if(err.name === 'ValidationError' ) {
            req.flash('error', err.message);
            res.redirect('back');
        }
        next(err);
    });
};

// GET /connections/:id: send details of connection identified by id
exports.show = (req, res, next) => {
    let id = req.params.id;
    model.findById(id).populate('hostName', 'firstName lastName')
    .then(connection=>{   
        if(connection) {
            return res.render('./connection/show', {connection});
        } else {
            let err = new Error('Cannot find a connection with id ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=>next(err));
    };

// GET /connections/:id/edit: send html form for editing an existing connection

exports.edit = (req, res, next) => { 
    let id = req.params.id;
    model.findById(id)
    .then(connection=>{
        console.log(connection);
        if(connection){
            return res.render('./connection/edit', {connection});
        } else {
            let err = new Error('Cannot find a connection with id ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=>next(err));
     };


    // DELETE / connection/:id, delete the connection identified by an id 
exports.delete = (req, res, next) => {   
    let id = req.params.id;
    model.findByIdAndDelete(id, {useFindAndModify: false})
    .then(connection =>{
        if(connection){
            req.flash('success', 'Connection Deleted Successfully !');
            res.redirect('/connections');
         } else {
            let err = new Error('Cannot find a connection with id ' + id);
            err.status = 404;
            return next(err);
        }
    })
    .catch(err=>next(err));
    };


// PUT /connections /:id update the connection identified by id // PUT method is used when we have to modify a single resource which is already a part of a resource collection

exports.update = (req, res, next) => {
    let id = req.params.id;
    let connection = req.body;
    model.findByIdAndUpdate(id, connection, {useFindAndModify: false, runValidators: true})
    .then(results=>{
        if(results){
            req.flash('success', 'Connection Updated Successfully !');
            res.redirect('/connections/'+id);      
        } else {
            let err = new Error('Cannot find a connection with id ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=> {
        if(err.name === 'ValidationError'){
            req.flash('error', err.message);
            res.redirect('back');
        }
            next(err);
    });
};



    