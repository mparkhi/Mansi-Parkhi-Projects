const { DateTime } = require('luxon');
const {v4: uuidv4} = require ('uuid');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;


const connectionSchema = new Schema({
    connectionTopic: {
        type: String, 
        required: [true, 'Connection topic field is required']
    },
    connectionName: {
        type: String, 
        required: [true, 'Connection Name field is required']
    },
    
    hostName : {type: Schema.Types.ObjectId, ref: 'User'
    },

    details: {
        type: String, 
        required: [true, 'Details field is required']
    },
    date: {
        type: String, 
        required: [true, 'Date field is required']
    },
    startTime: {
        type: String, 
        required: [true, 'Start time field is required']
    },
    endTime: {
        type: String, 
        required: [true, 'End time is required']
    },
    location: {
        type: String, 
        required: [true, 'Location field is required']
    },
    image: {
        type: String, 
        required: [true, 'Image field is required']
    },
},
    {timestamps: true}
);


module.exports = mongoose.model('Connection', connectionSchema);
