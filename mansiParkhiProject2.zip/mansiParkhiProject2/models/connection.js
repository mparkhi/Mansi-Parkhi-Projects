const { DateTime } = require('luxon');
const {v4: uuidv4} = require ('uuid');

const connections = [
{
    id:'1',
    connectionTopic: 'Indian Music',
    connectionName: 'Carnatic Music',
    hostName : 'Mansi Parkhi',
    details: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium',
    date: '2021-11-10',
    startTime:'05:15',
    endTime:'06:15',
    location: 'University Recreation Center, UNCC',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMm5N6vcL6IGP6-MW9DTYxDINtYwcLhCpfGA&usqp=CAU'
},
{
    id:'2',
    connectionTopic: 'Indian Music',    
    connectionName: 'Hindustani Music',
    hostName : 'Harshita Gupta',
    details: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium',
    date: '2021-11-10',
    startTime:'05:15',
    endTime:'06:15',
    location: 'University Recreation Center, UNCC',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMm5N6vcL6IGP6-MW9DTYxDINtYwcLhCpfGA&usqp=CAU'
},
{
    id:'3',
    connectionTopic: 'Indian Music',
    connectionName: 'Raaga Yaman',
    hostName : 'Mansi Parkhi',
    details: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium',
    date: '2021-11-10',
    startTime:'05:15',
    endTime:'06:15',
    location: 'University Recreation Center, UNCC',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMm5N6vcL6IGP6-MW9DTYxDINtYwcLhCpfGA&usqp=CAU'
    },

{
    id:'4',
    connectionTopic: 'Western Music',
    connectionName: 'World Music',
    hostName : 'Mansi Parkhi',
    details: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aene0an massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium',
    date: '2021-11-10',
    startTime:'05:15',
    endTime:'06:15',
    location: 'University Recreation Center, UNCC',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTf5anRUR7xtCauW2S8me3dt19InHYcQSdmEw&usqp=CAU'
},
{
    id:'5',
    connectionTopic: 'Western Music',
    connectionName: 'Jazz',
    hostName : 'Mansi Parkhi',
    details: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aene0an massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium',
    date: '2021-11-10',
    startTime:'05:15',
    endTime:'06:15',
    location: 'University Recreation Center, UNCC',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTf5anRUR7xtCauW2S8me3dt19InHYcQSdmEw&usqp=CAU'
},
{
    id:'6',
    connectionTopic: 'Western Music',
    connectionName: 'Rock',
    hostName : 'Harshita Gupta',
    details: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aene0an massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium',
    date: '2021-11-10',
    startTime:'05:15',
    endTime:'06:15',
    location: 'University Recreation Center, UNCC',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTf5anRUR7xtCauW2S8me3dt19InHYcQSdmEw&usqp=CAU' 
}     
];

const topics = ['Indian Music', 'Western Music'];

// create a function to add topics
exports.topics = () => topics; 

// create a function that will show the connections

exports.find = () => connections;

// create a function to show connection details

exports.findById = id => connections.find (connection => connection.id === id );

// Create a function to add the new connection into the array  
exports.save = function(connection){ console.log(connection);
    connection.id = uuidv4();
    if (topics.indexOf(connection.connectionTopic) === -1){ 
        topics.push(connection.connectionTopic);
    }
    connections.push(connection);
};

// create a function to update the connection
exports.updateById = function(id, newConnection) {
    let connection = connections.find (connection => connection.id === id );
    if (connection){
        if (topics.indexOf(newConnection.connectionTopic) === -1){
            topics.push(newConnection.connectionTopic);
        }
        connection.connectionTopic = newConnection.connectionTopic;
        connection.connectionName = newConnection.connectionName;
        connection.hostName = newConnection.hostName;
        connection.details = newConnection.details;
        connection.location = newConnection.location;
        connection.date = newConnection.date;  
        connection.startTime = newConnection.startTime;
        connection.endTime = newConnection.endTime;
        connection.image = newConnection.image;
        topics.forEach(topic => { 
            if(!connections.some(connection => connection.connectionTopic === topic)){
                let topicIndex = topics.indexOf(topic);
                if(topicIndex !== -1){
                    topics.splice(topicIndex, 1);
                }
            }
        }); 

        return true;
    } else {
        return false;
    }};

// create a function to delete the connection
exports.deleteById = function (id) {
    let index = connections.findIndex(connection => connection.id === id);
    if(index !== -1){
        let deletedConnection = connections.splice(index,1);
        if(!connections.some(connection => connection.connectionTopic === deletedConnection[0].connectionTopic)){
            let topicIndex = topics.indexOf(deletedConnection[0].connectionTopic);
            if(topicIndex !== -1){
                topics.splice(topicIndex, 1);
            }
        }
        return true;
    }else {
        return false;
    }
};  