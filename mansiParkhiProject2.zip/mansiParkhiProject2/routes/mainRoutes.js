const express = require('express');
const router = express.Router();
const controller = require('../controllers/mainController');

// GET /index : send the user to index page
router.get('/', controller.index); 

// GET /about : send the user to about page
router.get('/about', controller.about);

//  GET /contact : send the user to contact page
router.get('/contact', controller.contact);


module.exports = router;