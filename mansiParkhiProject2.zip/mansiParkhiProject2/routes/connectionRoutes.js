const express = require('express');
const router = express.Router();
const controller = require('../controllers/connectionController');

// GET / connections : send all connections to the user 
router.get('/', controller.index);

// GET /connections/new : send html form for creating a new connections
router.get('/new', controller.new);

// POST /connections: create a new connection // POST method is used when we have to add a child resource under an existing resource. 

router.post('/', controller.create);

// GET /connection/:id: send details of connection identified by id
router.get('/:id', controller.show);

// GET /connection/:id/edit: send html form for editing an existing connection

router.get('/:id/edit', controller.edit);

// PUT /connection /:id update the connection identified by id // PUT method is used when we have to modify a single resource which is already a part of a resource collection

router.put('/:id', controller.update);

// DELETE / connections/:id, delete the connection identified by an id 
router.delete('/:id', controller.delete);


module.exports = router;