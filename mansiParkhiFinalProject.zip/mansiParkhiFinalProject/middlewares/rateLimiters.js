const rateLimit = require('express-rate-limit');

exports.logInLimiter = rateLimit({
    
    windowMs : 60*1000,     // 1 minute time window 
    max: 5,                 // In 1 minute, client can request only 5 login requests, if login requests exceed 5, the system will show error message.
    //message: 'Too many Login requests, Try again later',
    handler : (req, res, next) => {
        let err = new Error('Too many Login requests, Please try again later');
        err.status = 429; 
        return next(err);
        
    }
   
});
