const express = require('express');
const router = express.Router();
const controller = require('../controllers/connectionController');
const{isLoggedIn, isHost} = require('../middlewares/auth');
const{validateId, validateConnection, validateResult} = require('../middlewares/validator');

// GET / connections : send all connections to the user 
router.get('/', controller.index);

// GET /connections/new : send html form for creating a new connections
router.get('/new',isLoggedIn, controller.new);

// POST /connections: create a new connection // POST method is used when we have to add a child resource under an existing resource. 

router.post('/',isLoggedIn, validateConnection, validateResult, controller.create);

// GET /connection/:id: send details of connection identified by id
router.get('/:id', validateId, controller.show);

// GET /connection/:id/edit: send html form for editing an existing connection

router.get('/:id/edit', isLoggedIn, validateId, isHost, controller.edit);

// PUT /connection /:id update the connection identified by id // PUT method is used when we have to modify a single resource which is already a part of a resource collection

router.put('/:id', isLoggedIn, validateId, isHost, validateConnection, validateResult, controller.update);

// DELETE / connections/:id delete the connection identified by an id 
router.delete('/:id', isLoggedIn, validateId, isHost, controller.delete);

//POST /connections/:id/rsvp: user response to rsvp
router.post('/:id/rsvp', validateId, isLoggedIn, controller.rsvp);

//DELETE /connections/rsvp/:id: delete the rsvp identified by id
router.delete('/rsvp/:id', validateId, isLoggedIn, controller.deleteRsvp);


module.exports = router;