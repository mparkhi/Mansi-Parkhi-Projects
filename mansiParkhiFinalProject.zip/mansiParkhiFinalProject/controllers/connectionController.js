const model = require('../models/connection');
const rsvp = require('../models/rsvp');
const {DateTime} = require ("luxon");



// show all the connections to the users
exports.index = (req, res, next) => { 
    model.distinct("connectionTopic", function(error, response){
        let connectionTopic = response;
         model.find()
        .then(connection_list => {
            res.render('./connection/index', {connections:connection_list, topics:connectionTopic})
        })
        .catch(err=>next(err));
    });    
};

// GET /connections/new : send html form for creating a new connection
exports.new = (req, res) => {
    res.render('./connection/new');
};


// POST /connections: create a new connection // We will add connection document into the database through this method 

exports.create = (req, res, next) => { 
    let today = new Date(DateTime.now().toFormat("yyyy-LL-dd"));
    let date = new Date(req.body.date);
    if(date.getTime() < today.getTime()){

        req.flash('error', 'Selected date must be greater than today\'s');
        res.redirect('back');
    }

    let connection = new model (req.body);
    connection.hostName = req.session.user;
    connection.save()
    .then(connection=> {

        req.flash('success', 'New connection created successfully');
        res.redirect('/connections');
    })
    .catch(err=>{

        if(err.name === 'ValidationError'){
            req.flash('error', err.message);
            res.redirect('back');

        }else{
            next(err);
        }
})};

// GET /connections/:id: send details of connection identified by id
exports.show = (req, res, next) => {
    let id = req.params.id;
    model.findById(id).populate('hostName', 'firstName lastName')
    .then(connection=>{
        if(connection) {
            connection.date = DateTime.fromSQL(connection.date).toFormat('LLLL dd, yyyy');
            connection.startTime = DateTime.fromSQL(connection.startTime).toFormat('hh:mm a');
            connection.endTime = DateTime.fromSQL(connection.endTime).toFormat('hh:mm a');
            console.log(connection);
            
            rsvp.countDocuments({ status: 'Yes', connection: id })
            .then(rsvpCount=>{
                return res.render('./connection/show', {connection, rsvpCount});
            })
            .catch(err=>next(err));
            
        } else {
            let err = new Error('Cannot find a connection with id ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=>next(err));
    
};


// GET /connections/:id/edit: send html form for editing an existing connection

exports.edit = (req, res, next) => { 
    let id = req.params.id;
    model.findById(id)
    .then(connection=>{
        if(connection){
            return res.render('./connection/edit', {connection});
        } else {
            let err = new Error('Cannot find a connection with id ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=>next(err));
     };


    // DELETE / connection/:id, delete the connection identified by an id 
exports.delete = (req, res, next) => {   
    let id = req.params.id;
    model.findByIdAndDelete(id, {useFindAndModify: false})
    .then(connection =>{
        if(connection){
            req.flash('success', 'Connection Deleted Successfully !');
            res.redirect('/connections');
         } else {
            let err = new Error('Cannot find a connection with id ' + id);
            err.status = 404;
            return next(err);
        }
    })
    .catch(err=>next(err));
    };


// PUT /connections /:id update the connection identified by id // PUT method is used when we have to modify a single resource which is already a part of a resource collection

exports.update = (req, res, next) => {
    let id = req.params.id;
    let connection = req.body;
    model.findByIdAndUpdate(id, connection, {useFindAndModify: false, runValidators: true})
    .then(results=>{
        if(results){
            req.flash('success', 'Connection Updated Successfully !');
            res.redirect('/connections/'+id);      
        } else {
            let err = new Error('Cannot find a connection with id ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=> {
        if(err.name === 'ValidationError'){
            req.flash('error', err.message);
            res.redirect('back');
        }
            next(err);
    });
};

// RSVP related actions 
exports.rsvp = (req, res, next) => {
    let userId = req.session.user;
    
    let id = req.params.id;

    let status = req.body.status;


    model.findById(id)
    .then(connection=>{

        if(connection) {

            if(connection.hostName==userId){

                let err = new Error('Unauthorized to access the resource');
                err.status = 401;
                return next(err);
            }else{

                rsvp.updateOne({ connection: id, userId: userId }, { $set: { connection: id, userId: userId, status: status }}, { upsert: true })
                .then(rsvp=>{
                    if(rsvp) {
                        if(!rsvp.upserted){
                            req.flash('success', 'RSVP has been successfully updated');
                            
                        }else{
                            req.flash('success', 'RSVP has been successfully created');

                        }
                        res.redirect('/users/profile');
                    } else {

                        req.flash('error', 'Looks like something went wrong');
                        res.redirect('back');
                    }
                })
                .catch(err=> {
                    if(err.name === 'ValidationError'){

                        req.flash('error', err.message);
                        res.redirect('back');
                    }else{
                        next(err);
                    }
                });
            }
        } else {

            let err = new Error('Cannot find a connection with id ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=>next(err));
    
};

exports.deleteRsvp = (req, res, next) => {

    let id = req.params.id;

    rsvp.findByIdAndDelete(id, {useFindAndModify: false})
    .then(rsvp =>{

        if(rsvp) {

            req.flash('success', 'RSVP has been sucessfully deleted!');
            res.redirect('/users/profile');
        } else {

            let err = new Error('Cannot find an RSVP with id ' + id);
            err.status = 404;
            return next(err);
        }
    })
    .catch(err=>next(err));
};